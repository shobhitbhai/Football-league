# AFL
Live Score Update of Football Match tof Acharya Institutes, Bangalore.

### Steps to run App on your System.

To install all dependencies, type command in terminal from your project folder.
```
npm intall
```

To run Server in development mode, run command
```
npm run dev
```

To run server in normal mode, run command
```
node app.js
```

It will show up as 
```
App Listening on 3000
```

Open http://localhost:3000 on your browser.

Thankyou.
